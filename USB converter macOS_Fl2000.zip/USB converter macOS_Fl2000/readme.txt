macos 11 install version 1.4.2

below macos 11 install version 1.5.2